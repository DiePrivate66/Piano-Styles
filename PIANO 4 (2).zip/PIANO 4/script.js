document.addEventListener('DOMContentLoaded', () => {
    // --- Elementos de la UI ---
    const ui = {
        body: document.body,
        screens: document.querySelectorAll('.screen'),
        authContainer: document.getElementById("auth-container"),
        loginScreen: document.getElementById("login-screen"),
        registerScreen: document.getElementById("register-screen"),
        menu: document.getElementById("menu"),
        gameContainer: document.getElementById("game-container"),
        gameOver: document.getElementById("game-over"),
        profileScreen: document.getElementById("profile-screen"),
        loginForm: document.getElementById("login-form"),
        registerForm: document.getElementById("register-form"),
        showRegisterLink: document.getElementById("show-register-link"),
        showLoginLink: document.getElementById("show-login-link"),
        logoutBtn: document.getElementById("logout-btn"),
        profileBtn: document.getElementById("profile-btn"),
        backToMenuBtn: document.getElementById("back-to-menu-btn"),
        playBtn: document.getElementById('play-btn'),
        retryBtn: document.getElementById('retry-btn'),
        menuBtn: document.getElementById('menu-btn'),
        welcomeMessage: document.getElementById("welcome-message"),
        highScoreDisplay: document.getElementById("high-score"),
        finalScore: document.getElementById("final-score"),
        scoreText: document.getElementById("score"),
        songSelect: document.getElementById('song-select'),
        bgMusic: document.getElementById("bg-music"),
        game: document.getElementById("game"),
        achievementsList: document.getElementById("achievements-list"),
        profileUsername: document.getElementById('profile-username'),
        gamesPlayed: document.getElementById('games-played'),
        profileHighScore: document.getElementById('profile-high-score'),
        notificationContainer: document.getElementById('notification-container'),
        gameModeSelectScreen: document.getElementById('game-mode-select'),
        animalGameContainer: document.getElementById('animal-game-container'),
        animalGame: document.getElementById('animal-game'),
        animalScoreText: document.getElementById('animal-score'),
        playPianoBtn: document.getElementById('play-piano-btn'),
        playAnimalBtn: document.getElementById('play-animal-btn'),
        backToMainMenuBtn: document.getElementById('back-to-main-menu-btn'),
        levelCompleteScreen: document.getElementById('level-complete'),
        levelCompleteScore: document.getElementById('level-complete-score'),
        retryLevelBtn: document.getElementById('retry-level-btn'),
        mainMenuBtn: document.getElementById('main-menu-btn'),
    };

    // --- Variables de estado del Juego ---
    let score = 0, animationFrameId;
    let isGameOver = false;
    let lastGamePlayed = null; 

    // Variables para el juego de Piano
    let columns = [], activeTiles = [];
    let fallSpeed = 5;
    let currentSong = null;
    let songPosition = 0;
    let beatInterval = 0;
    let lastBeatTime = 0;
    const audioList = [ new Audio("sounds/piano1.mp3"), new Audio("sounds/piano2.mp3"), new Audio("sounds/piano3.mp3"), new Audio("sounds/piano4.mp3") ];

    // Variables de dificultad del piano ajustadas para ser más agresivas
    let initialFallSpeed = 4;
    let maxFallSpeed = 15;
    let speedIncreaseAmount = 0.6;
    let bpmIncreaseAmount = 8;
    let difficultyIncreaseInterval = 15;
    let nextDifficultyIncreaseScore = difficultyIncreaseInterval;
    
    // Variables para el juego de Animales
    let animalFallSpeed = 4;
    let activeAnimals = [];
    let animalSpawnInterval;
    let basket = null;
    const ANIMAL_IMAGES = [
        'img/animals/cat.png', 'img/animals/dog.png', 'img/animals/fox.png', 'img/animals/bear.png'
    ];
    
    // Variables para dificultad progresiva de Animales
    let animalDifficultyIncreaseInterval = 10;
    let nextAnimalDifficultyIncreaseScore = animalDifficultyIncreaseInterval;
    let animalSpeedIncreaseAmount = 0.5;
    let maxAnimalFallSpeed = 10;
    let animalSpawnRate = 1200;
    let minAnimalSpawnRate = 400;
    let animalSpawnRateDecrease = 100;

    let currentUser = null;
    let users = JSON.parse(localStorage.getItem('pianoUsers')) || [];

    const ACHIEVEMENTS = {
        first_game: { name: 'Principiante', desc: 'Juega tu primera partida.' },
        score_50: { name: 'Pianista Aficionado', desc: 'Alcanza 50 puntos en una canción.' },
        score_100: { name: 'Virtuoso', desc: '¡Alcanza 100 puntos en una canción!' },
        play_10: { name: 'Dedicado', desc: 'Juega 10 partidas.' }
    };

    // --- LÓGICA DE UI Y NAVEGACIÓN ---
    function loadSongsIntoSelector() {
        if (typeof SONGS === 'undefined' || SONGS.length === 0) {
            console.error("Error: El archivo songs.js no se cargó o está vacío.");
            const option = document.createElement('option');
            option.textContent = "No hay canciones";
            option.disabled = true;
            ui.songSelect.appendChild(option);
            return;
        }
        SONGS.forEach((song, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.textContent = song.name;
            ui.songSelect.appendChild(option);
        });
    }

    function showScreen(screenId) {
        if (screenId === 'auth-container') ui.body.classList.add('auth-background-active');
        else ui.body.classList.remove('auth-background-active');
        
        if (screenId === 'game-mode-select') {
            ui.playPianoBtn.disabled = false;
            ui.playAnimalBtn.disabled = false;
        }
        
        ui.screens.forEach(screen => screen.classList.remove('active'));
        document.getElementById(screenId).classList.add('active');
    }

    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        ui.notificationContainer.appendChild(notification);
        setTimeout(() => notification.remove(), 3000);
    }

    function showMenu() {
        showScreen('menu');
        ui.welcomeMessage.textContent = `¡Hola, ${currentUser.username}!`;
        ui.highScoreDisplay.textContent = currentUser.highScore;
    }

    function showProfile() {
        showScreen('profile-screen');
        ui.profileUsername.textContent = currentUser.username;
        ui.gamesPlayed.textContent = currentUser.gamesPlayed;
        ui.profileHighScore.textContent = currentUser.highScore;
        renderAchievements();
    }

    function renderAchievements() {
        ui.achievementsList.innerHTML = '';
        for (const id in ACHIEVEMENTS) {
            const achievement = ACHIEVEMENTS[id];
            const isUnlocked = currentUser.achievements.includes(id);
            const div = document.createElement('div');
            div.className = `achievement ${isUnlocked ? 'unlocked' : ''}`;
            div.innerHTML = `<h4>${achievement.name}</h4><p>${achievement.desc}</p>`;
            ui.achievementsList.appendChild(div);
        }
    }

    // --- LÓGICA DE AUTENTICACIÓN Y DATOS ---
    function registerUser(e) {
        e.preventDefault();
        const username = document.getElementById('register-username').value;
        const email = document.getElementById('register-email').value;
        if (users.find(user => user.email === email)) {
            showNotification('Este correo ya está registrado.', 'error');
            return;
        }
        const newUser = { username, email, highScore: 0, gamesPlayed: 0, achievements: [] };
        users.push(newUser);
        saveUsers();
        showNotification('¡Usuario registrado con éxito!');
        ui.registerForm.reset();
        ui.showLoginLink.click();
    }

    function loginUser(e) {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const user = users.find(u => u.email === email);
        if (user) {
            currentUser = user;
            showMenu();
        } else {
            showNotification('Correo o usuario no encontrado.', 'error');
        }
    }

    function logoutUser() {
        currentUser = null;
        showScreen('auth-container');
        ui.loginScreen.style.display = 'block';
        ui.registerScreen.style.display = 'none';
        ui.loginForm.reset();
    }

    function saveUsers() {
        localStorage.setItem('pianoUsers', JSON.stringify(users));
    }

    function updateUserDataAfterGame() {
        currentUser.gamesPlayed++;
        if (score > currentUser.highScore) {
            currentUser.highScore = score;
        }
        const checkAchievement = (id) => {
            if (!currentUser.achievements.includes(id)) {
                currentUser.achievements.push(id);
                const achievement = ACHIEVEMENTS[id];
                showNotification(`🏆 Logro desbloqueado: ${achievement.name}`);
            }
        }
        if (currentUser.gamesPlayed >= 1) checkAchievement('first_game');
        if (score >= 50) checkAchievement('score_50');
        if (score >= 100) checkAchievement('score_100');
        if (currentUser.gamesPlayed >= 10) checkAchievement('play_10');
        const userIndex = users.findIndex(u => u.email === currentUser.email);
        if (userIndex !== -1) users[userIndex] = currentUser;
        saveUsers();
    }

    // --- LÓGICA DEL JUEGO DE PIANO ---
    function startPianoGame() {
        lastGamePlayed = 'piano';
        const songIndex = ui.songSelect.value;
        currentSong = SONGS[songIndex];
        if (!currentSong) {
            showNotification("Por favor, selecciona una canción.", "error");
            showScreen('game-mode-select');
            return;
        }
        showScreen('game-container');
        isGameOver = false;
        score = 0;
        songPosition = 0;
        lastBeatTime = 0;
        
        fallSpeed = initialFallSpeed;
        beatInterval = 60000 / currentSong.bpm;
        nextDifficultyIncreaseScore = difficultyIncreaseInterval;
        
        ui.scoreText.textContent = "Puntaje: 0";
        activeTiles.forEach(t => t.element.remove());
        activeTiles = [];
        ui.bgMusic.src = currentSong.audioSrc;
        ui.bgMusic.currentTime = 0;
        ui.bgMusic.play().catch(e => console.log("Audio necesita interacción del usuario."));
        ui.game.innerHTML = "";
        columns = Array.from({ length: 4 }, () => {
            const col = document.createElement("div");
            col.classList.add("column");
            ui.game.appendChild(col);
            return col;
        });
        animationFrameId = requestAnimationFrame(pianoGameLoop);
    }
    
    function increasePianoDifficulty() {
        if (fallSpeed < maxFallSpeed) {
            fallSpeed += speedIncreaseAmount;
        }
        let currentBPM = 60000 / beatInterval;
        let newBPM = currentBPM + bpmIncreaseAmount;
        beatInterval = 60000 / newBPM;
        showNotification("¡Más rápido!", "error");
    }

    function completeLevel() {
        if (isGameOver) return;
        isGameOver = true;
        cancelAnimationFrame(animationFrameId);
        ui.bgMusic.pause();
        updateUserDataAfterGame();
        showScreen('level-complete');
        ui.levelCompleteScore.textContent = score;
    }
    
    function pianoGameLoop(timestamp) {
        if (isGameOver) return;

        if (songPosition >= currentSong.notes.length && activeTiles.length === 0) {
            completeLevel();
            return;
        }

        for (let i = activeTiles.length - 1; i >= 0; i--) {
            const tile = activeTiles[i];
            tile.y += fallSpeed;
            tile.element.style.transform = `translateY(${tile.y}px) scale(${tile.element.classList.contains('clicked') ? 0.95 : 1})`;
            if (tile.y > ui.game.offsetHeight) {
                if (!tile.clicked) {
                    endPianoGame();
                    return;
                }
            }
        }

        if (timestamp - lastBeatTime > beatInterval) {
            if (songPosition < currentSong.notes.length) {
                lastBeatTime = timestamp;
                spawnNextTile();
            }
        }
        
        animationFrameId = requestAnimationFrame(pianoGameLoop);
    }

    function spawnNextTile() {
        const colIndex = currentSong.notes[songPosition];
        songPosition++;
        if (colIndex === -1) return;
        
        const tileElement = document.createElement("div");
        tileElement.classList.add("tile");
        const tile = { element: tileElement, y: -150, column: colIndex, clicked: false };
        
        tileElement.addEventListener('click', () => {
            if (isGameOver || tile.clicked) return;
            tile.clicked = true;
            tileElement.classList.add("clicked");
            
            score++;
            ui.scoreText.textContent = "Puntaje: " + score;

            if (score >= nextDifficultyIncreaseScore) {
                increasePianoDifficulty();
                nextDifficultyIncreaseScore += difficultyIncreaseInterval; 
            }

            const noteSound = audioList[tile.column].cloneNode();
            noteSound.play();

            const tileIndex = activeTiles.indexOf(tile);
            if (tileIndex > -1) activeTiles.splice(tileIndex, 1);
            
            setTimeout(() => tileElement.remove(), 200);
        });
        
        columns[colIndex].appendChild(tileElement);
        activeTiles.push(tile);
    }

    function endPianoGame() {
        if (isGameOver) return;
        isGameOver = true;
        cancelAnimationFrame(animationFrameId);
        ui.bgMusic.pause();
        activeTiles.forEach(tile => {
            if (!tile.clicked) tile.element.classList.add('missed');
        });
        setTimeout(() => {
            showScreen('game-over');
            ui.finalScore.textContent = score;
            updateUserDataAfterGame();
        }, 500);
    }

    // --- LÓGICA DEL JUEGO DE ATRAPAR ANIMALES ---
    function startAnimalGame() {
        lastGamePlayed = 'animal';
        showScreen('animal-game-container');
        isGameOver = false;
        score = 0;
        // --- LÍNEA CORREGIDA ---
        ui.animalScoreText.textContent = "Puntaje: 0";
        activeAnimals.forEach(a => a.element.remove());
        activeAnimals = [];
        ui.animalGame.innerHTML = '';
        
        animalFallSpeed = 4;
        animalSpawnRate = 1200;
        nextAnimalDifficultyIncreaseScore = animalDifficultyIncreaseInterval;

        createBasket();
        ui.animalGame.addEventListener('mousemove', moveBasket);

        clearInterval(animalSpawnInterval);
        animalSpawnInterval = setInterval(spawnAnimal, animalSpawnRate);
        animationFrameId = requestAnimationFrame(animalGameLoop);
    }
    
    function increaseAnimalDifficulty() {
        if (animalFallSpeed < maxAnimalFallSpeed) {
            animalFallSpeed += animalSpeedIncreaseAmount;
        }
        if (animalSpawnRate > minAnimalSpawnRate) {
            animalSpawnRate -= animalSpawnRateDecrease;
        }

        clearInterval(animalSpawnInterval);
        animalSpawnInterval = setInterval(spawnAnimal, animalSpawnRate);

        showNotification("¡Más animalitos!", "error");
    }

    function createBasket() {
        basket = document.createElement('div');
        basket.id = 'basket';
        ui.animalGame.appendChild(basket);
    }

    function moveBasket(e) {
        if (isGameOver || !basket) return;
        const gameRect = ui.animalGame.getBoundingClientRect();
        let basketX = e.clientX - gameRect.left - (basket.offsetWidth / 2);
        if (basketX < 0) basketX = 0;
        if (basketX > gameRect.width - basket.offsetWidth) basketX = gameRect.width - basket.offsetWidth;
        basket.style.left = `${basketX}px`;
    }

    function spawnAnimal() {
        if (isGameOver) return;
        const animal = document.createElement('div');
        animal.classList.add('animal-block');
        const randomImage = ANIMAL_IMAGES[Math.floor(Math.random() * ANIMAL_IMAGES.length)];
        animal.style.backgroundImage = `url('${randomImage}')`;
        const startX = Math.random() * (ui.animalGame.offsetWidth - 60);
        animal.style.left = `${startX}px`;
        animal.style.top = '-60px';
        ui.animalGame.appendChild(animal);
        activeAnimals.push({ element: animal, y: -60, x: startX });
    }

    function animalGameLoop() {
        if (isGameOver) return;
        const basketRect = basket ? basket.getBoundingClientRect() : null;
        for (let i = activeAnimals.length - 1; i >= 0; i--) {
            const animal = activeAnimals[i];
            animal.y += animalFallSpeed;
            animal.element.style.transform = `translateY(${animal.y}px)`;
            
            const animalRect = animal.element.getBoundingClientRect();
            if (basketRect && animalRect.bottom >= basketRect.top && animalRect.left < basketRect.right && animalRect.right > basketRect.left && animalRect.top < basketRect.bottom) {
                score++;
                ui.animalScoreText.textContent = "Puntaje: " + score;
                animal.element.remove();
                activeAnimals.splice(i, 1);

                if (score >= nextAnimalDifficultyIncreaseScore) {
                    increaseAnimalDifficulty();
                    nextAnimalDifficultyIncreaseScore += animalDifficultyIncreaseInterval;
                }
            } else if (animal.y > ui.animalGame.offsetHeight) {
                endAnimalGame();
                return;
            }
        }
        animationFrameId = requestAnimationFrame(animalGameLoop);
    }

    function endAnimalGame() {
        if (isGameOver) return;
        isGameOver = true;
        cancelAnimationFrame(animationFrameId);
        clearInterval(animalSpawnInterval);
        ui.animalGame.removeEventListener('mousemove', moveBasket);
        if(basket) basket.style.filter = 'grayscale(100%)';
        setTimeout(() => {
            showScreen('game-over');
            ui.finalScore.textContent = score;
            updateUserDataAfterGame();
        }, 800);
    }

    // --- INICIALIZACIÓN DE EVENTOS ---
    function init() {
        loadSongsIntoSelector();
        showScreen('auth-container');

        ui.showRegisterLink.addEventListener('click', (e) => { e.preventDefault(); ui.loginScreen.style.display = 'none'; ui.registerScreen.style.display = 'block'; });
        ui.showLoginLink.addEventListener('click', (e) => { e.preventDefault(); ui.registerScreen.style.display = 'none'; ui.loginScreen.style.display = 'block'; });

        ui.registerForm.addEventListener('submit', registerUser);
        ui.loginForm.addEventListener('submit', loginUser);
        ui.logoutBtn.addEventListener('click', logoutUser);
        ui.profileBtn.addEventListener('click', showProfile);
        ui.backToMenuBtn.addEventListener('click', showMenu);
        ui.menuBtn.addEventListener('click', showMenu);
        ui.playBtn.addEventListener('click', () => showScreen('game-mode-select'));
        
        const retryGame = () => {
            if (lastGamePlayed === 'piano') startPianoGame();
            else if (lastGamePlayed === 'animal') startAnimalGame();
        };

        ui.retryBtn.addEventListener('click', retryGame);
        
        ui.retryLevelBtn.addEventListener('click', retryGame);
        ui.mainMenuBtn.addEventListener('click', showMenu);

        ui.playPianoBtn.addEventListener('click', () => { ui.playPianoBtn.disabled = true; ui.playAnimalBtn.disabled = true; startPianoGame(); });
        ui.playAnimalBtn.addEventListener('click', () => { ui.playPianoBtn.disabled = true; ui.playAnimalBtn.disabled = true; startAnimalGame(); });
        ui.backToMainMenuBtn.addEventListener('click', showMenu);
    }

    init();
});